package ArrayList2;

public class StaffTester {
    public static void main(String[] args) {
    Staff staff = new Staff("Austin", "6134Bent","Lakeland", 10000);
    System.out.println(staff.toString());
    }

}
