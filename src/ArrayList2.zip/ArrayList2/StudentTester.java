package ArrayList2;

public class StudentTester {
    public static void main(String[] args) {
        Student student = new Student("Austin", "6134Bent", "ComputerProgramming", 2004, 109);
        System.out.println(student.toString());
    }

}
